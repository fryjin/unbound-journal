# Journal Project — 首轮开发基准包

版本：P0 Baseline v1  
日期：2026-08-10

## 1. 项目目标

这是一个 **Global-first、Mobile-first、Native-ready** 的数字手账创作与记录产品。

第一阶段先开发移动端优先 HTML / PWA 原型与 MVP，成熟后再迁移到原生 iOS / Android。

产品第一核心能力不是“写日记”，而是：

> 先通过纸张的铺、叠、擦、换完成页面设计，再加入文字、照片、视频、手写与涂鸦。

---

## 2. 首轮唯一核心目标

首轮版本：

**P0 — Paper Engine Prototype**

P0 只验证一件事：

> 用户能否在手机上自然地用多种纸张进行铺纸、叠纸、擦纸和换纸，并形成明显具有实体手账拼贴感的页面。

P0 不做首页、账号、云同步、商城、支付、创作者中心、照片、视频、正式文字输入、手写或社区。

---

## 3. 开发协作方式

项目采用：

- ChatGPT：前期主导
- Codex：复杂工程阶段接管
- GitHub：唯一代码与文档主仓库
- Cloudflare：后续部署与云端基础设施

### ChatGPT 前期主导范围

ChatGPT 优先完成：

1. 产品与交互规则冻结
2. 技术架构与数据 Schema
3. 仓库初始化方案
4. 轻量前端原型与基础代码
5. Paper Runtime Asset Contract
6. 测试纸张资产生成方案
7. 初版 Paper Engine 可行性实现
8. 开发任务拆分与验收

### Codex 接管条件

当工作进入以下类型时，优先交给 Codex：

- 多包、多模块重构
- Gesture Router 与多指手势冲突
- 高频 Canvas / Mask 性能优化
- 复杂 Undo / Redo Command History
- IndexedDB 可靠持久化
- iPhone Safari / Android Chrome 真机兼容问题
- 大量自动化测试
- 大规模代码审查、重构与 CI

原则：

> 前期不是为了“把工作交给 Codex”而交给 Codex。  
> 能由 ChatGPT 快速、清晰、低风险完成的内容优先由 ChatGPT 完成；复杂、持续、多文件工程工作再切给 Codex。

---

## 4. 基准文档

本包包含：

- `01_PRODUCT_PRINCIPLES.md`
- `02_ARCHITECTURE.md`
- `03_PAPER_ASSET_SPEC_V1.md`
- `04_P0_DEVELOPMENT_SPEC.md`
- `05_CHATGPT_CODEX_WORKFLOW.md`
- `06_P0_ACCEPTANCE_CHECKLIST.md`
- `07_DECISIONS_AND_OPEN_ITEMS.md`

这些文件应提交至 GitHub，并作为 P0 的唯一基准。

---

## 5. 市场与语言优先级

Tier 1：

- English
- Japanese (`ja-JP`)
- Korean (`ko-KR`)

Tier 2：

- Traditional Chinese (`zh-Hant`)

当前不做：

- Simplified Chinese 产品地区专项体验

英文为 Source Locale。

---

## 6. P0 Definition of Done

> A first-time user can create a clearly layered, collage-like journal page on a phone using at least three different paper styles through painting, layering and erasing, without instructions, and the result remains intact after reload.

只有满足这条，P0 才算通过。
